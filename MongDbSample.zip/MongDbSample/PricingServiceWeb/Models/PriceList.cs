﻿using PricingServiceWeb.Data.Model;

namespace PricingServiceWeb.Models
{
    public class PriceList : AdjustPrice
    {

    }
}