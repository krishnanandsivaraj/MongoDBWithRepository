﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongDbSample.Data;
using MongDbSample.Data.Model;

namespace MongDbSample.Models
{
    public class Product : Products
    {
    }
}